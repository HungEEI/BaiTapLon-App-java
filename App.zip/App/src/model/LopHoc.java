package model;

public class LopHoc {

	private int id;
	private String tenPhong;
	private int soLuong;
	private boolean trangThai;
	
	
	
}
